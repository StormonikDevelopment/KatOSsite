
var userid = [

               
			

]




function check(form)
{

	if(form.userid.value = "bigblack" && form.pwd.value == "niggaballs")

{
	return true;
}
else
{
	alert("Error Password or Username")
	return false;
}
}





